var Alere = window.Alere || {};


$(document).ready(function() {
	/** 
	 * - SideBar Nav - 
	 * For accessability purposes, all nav items are expanded by default so 
	 * that each item can be accesed regardless of JavaScript availability.
	 **/
	
	// Hide each sub sub nav whose parent is not selected
	$("ul#side-bar-nav > :not(li[class='selected'])").find('ul').hide();
	
	// Add click event that expands a sub sub menu	
	$('ul#side-bar-nav > li').click(function(e) {
		e.preventDefault();
		$(this).toggleClass('selected').find('ul').toggle('fast');
	});
	
	
	/**
	 * Main Menu Navigation 
	 **/
	Alere.Menu = {};
	
	Alere.Menu.close = function() {
		$('ul#top-nav > li').removeClass('selected');
		$('ul#top-nav div.top-nav-sub').hide();
	};
	
	Alere.Menu.open = function(menuItem) {
		// Close all
		clearTimeout(Alere.Menu.timeout);
		$('ul#top-nav > li').removeClass('selected');
		$('ul#top-nav div.top-nav-sub').hide();
		// Open one
		$(menuItem).toggleClass('selected').find('div.top-nav-sub').slideDown('fast');
	};
	
	Alere.Menu.timeout = null;
	// Add click event that expands a sub sub menu	
	$("ul#top-nav > li").click(function(e) {
		e.preventDefault();
		Alere.Menu.open(this);
		$(this).bind('mouseleave', function(e) {
			clearTimeout(Alere.Menu.timeout);
			Alere.Menu.timeout = setTimeout(function() {
				Alere.Menu.close();
			}, 400);
		}).bind('mouseenter', function(e) { 
			clearTimeout(Alere.Menu.timeout);
		});
	});
	

	/** 
	 *	Module Utility Nav interaction model 
	 **/
	// Show more like this button
	$('div.main-well div.module div.more').hide();
	$('ul.utility-nav li.tell-more a').click(function(e) {
		e.preventDefault();
		$(this).parent().toggleClass('selected');
		$(this).closest('div.module').find('div.more').toggle('fast');
	});
	
	// Don't show this again button
	$('ul.utility-nav li.dont-show a').click(function(e) {
		e.preventDefault();
		var confirmBox = $(this).parent().find('div.dont-show-confirm');
		confirmBox.fadeIn('fast');
		confirmBox.find('a:first').one('click', function(e) {
			e.preventDefault();
			confirmBox.fadeOut('fast');
		});
		confirmBox.find('a:last').one('click', function(e) {
			e.preventDefault();
			confirmBox.hide();
			$(this).closest('div.module').fadeOut('slow');
		});
	});
	
	
	// Tell me more button
	$('ul.utility-nav li.show-more a').click(function(e) {
		e.preventDefault();

		// Clone a random module and insert it
		var totalNumberOfModules = $('div.main-well div.module').length;
		var randomModuleIndex = Math.ceil(Math.random() * totalNumberOfModules - 1);
 		var randomModuleNode = $('div.main-well div.module').get(randomModuleIndex);
		var clonedNode = $(randomModuleNode).clone(true);
		clonedNode.hide();
		$(this).closest('div.module').after(clonedNode);
		clonedNode.fadeIn('slow');
	});
	
	
	/** 
	 *	True / False Quiz  
	 **/
	
	var trueFalseForms = $('form.true-false');
	$('div.module div.answer').hide();
	trueFalseForms.find('label.true input').click(function() {
		var answerDiv = $(this).closest('div.module').find('div.answer')
		answerDiv.fadeIn('fast');		
		$(this).closest('fieldset').hide();
		answerDiv.find('h6.true').show();
		answerDiv.find('h6.false').hide();
	});
	
	trueFalseForms.find('label.second input').click(function() {
		var answerDiv = $(this).closest('div.module').find('div.answer')
		answerDiv.fadeIn('fast');
		$(this).closest('fieldset').hide();
		answerDiv.find('h6.true').hide();
		answerDiv.find('h6.false').show();
	});
	
	
	
	/** 
	 * Checklist Paginator
	 **/
	var paginator = $('div.program-checklist ul.pagination');
	var numberOfItems = $('div.program-checklist form').find('fieldset').hide().length;
	var currentItem = 0;
	
	$('div.program-checklist form').find('fieldset:first').show();
	$('div.program-checklist form').find('fieldset:first').addClass('selected');
	
	// By default hide previous button
	paginator.find('a.prev').hide();
	paginator.find('a.next').click(function(e) {
		e.preventDefault();
		// Slide out the current fieldset
		var selected = $(this).closest('form').find('fieldset.selected').css({position:'absolute', top:'0'}).animate({top:'0px', left:'-350px'}, 'slow').removeClass('selected');
		
		// Increment
		currentItem++;
		
		// Fade out next button if we're on the last item
		if(currentItem == numberOfItems - 1) {
			$(this).fadeOut();
		}
		
		// Fade in prev button if the current slide is more than 0
		if(currentItem > 0) {
			paginator.find('a.prev').fadeIn();
		}
		
		$(this).closest('form').find('fieldset:eq(' + currentItem + ')').css({left:'auto', position:'relative', right:'-350px'}).show().animate({right:'0px'}, 'slow').addClass('selected');

	});
	
	paginator.find('a.prev').click(function(e) {
		e.preventDefault();
		
		// Slide out the current fieldset
		var selected = $(this).closest('form').find('fieldset.selected').css({left:'auto', position:'absolute', top:'0'}).animate({top:'0px', right:'-350px'}, 'slow').removeClass('selected');
		
		// Decrement
		currentItem--;
		
		// Fade out prev button if we're on the first item
		if(currentItem == 0) {
			$(this).fadeOut();
		}
		
		// Fade in next button if the current slide is more than 0
		if(currentItem > 0) {
			paginator.find('a.next').fadeIn();
		}
		
		$(this).closest('form').find('fieldset:eq(' + currentItem + ')').css({position:'relative', left:'-350px'}).show().animate({left:'0px'}, 'slow').addClass('selected');

	});
	
	/**
	 * Set up example for inputs
	 **/
	$('input.example-text').example(function() {
	   return $(this).attr('title'); 
	});
	
	
});