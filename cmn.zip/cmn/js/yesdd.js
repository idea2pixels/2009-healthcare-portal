		$(document).ready(function(){
			$('#yes_layer1').hide('fast');
			$('#yes_layer2').hide('fast');
			$('#yes_layer3').hide('fast');
			$('#yes_layer4').hide('fast');
			$('#yes_layer5').hide('fast');
			$('#yes_layer6').hide('fast');
			$('#yes_layer7').hide('fast');
			$('#yes_layer8').hide('fast');
			$('#yes_layer9').hide('fast');
			$('#yes_layer10').hide('fast');
			$('#yes_layer11').hide('fast');
			$('#yes_layer12').hide('fast');
			$('#yes_layer13').hide('fast');
			$('#yes_layer14').hide('fast');
			$('#yes_layer15').hide('fast');
		
		});
		
		
		$(function() {
			// shows the slickbox on clicking the noted link
 			$('#show1 .jNiceRadio').click(function() {
			$('#yes_layer1').show('slow');
			return false;
 			});
			
			// hides the slickbox on clicking the noted link
 			$('#hide1 .jNiceRadio').click(function() {
			$('#yes_layer1').hide('fast');
			return false;
 			});
					// shows the slickbox on clicking the noted link
 			$('#show2 .jNiceRadio').click(function() {
			$('#yes_layer2').show('slow');
			return false;
 			});
			
			// hides the slickbox on clicking the noted link
 			$('#hide2 .jNiceRadio').click(function() {
			$('#yes_layer2').hide('fast');
			return false;
 			});
					// shows the slickbox on clicking the noted link
 			$('#show3 .jNiceRadio').click(function() {
			$('#yes_layer3').show('slow');
			return false;
 			});
			
			// hides the slickbox on clicking the noted link
 			$('#hide3 .jNiceRadio').click(function() {
			$('#yes_layer3').hide('fast');
			return false;
 			});
					// shows the slickbox on clicking the noted link
 			$('#show4 .jNiceRadio').click(function() {
			$('#yes_layer4').show('slow');
			return false;
 			});
			
			// hides the slickbox on clicking the noted link
 			$('#hide4 .jNiceRadio').click(function() {
			$('#yes_layer4').hide('fast');
			return false;
 			});
					// shows the slickbox on clicking the noted link
 			$('#show5 .jNiceRadio').click(function() {
			$('#yes_layer5').show('slow');
			return false;
 			});
			
			// hides the slickbox on clicking the noted link
 			$('#hide5 .jNiceRadio').click(function() {
			$('#yes_layer5').hide('fast');
			return false;
 			});
					// shows the slickbox on clicking the noted link
 			$('#show6 .jNiceRadio').click(function() {
			$('#yes_layer6').show('slow');
			return false;
 			});
			
			// hides the slickbox on clicking the noted link
 			$('#hide6 .jNiceRadio').click(function() {
			$('#yes_layer6').hide('fast');
			return false;
 			});
					// shows the slickbox on clicking the noted link
 			$('#show7 .jNiceRadio').click(function() {
			$('#yes_layer7').show('slow');
			return false;
 			});
			
			// hides the slickbox on clicking the noted link
 			$('#hide7 .jNiceRadio').click(function() {
			$('#yes_layer7').hide('fast');
			return false;
 			});
					// shows the slickbox on clicking the noted link
 			$('#show8 .jNiceRadio').click(function() {
			$('#yes_layer8').show('slow');
			return false;
 			});
			
			// hides the slickbox on clicking the noted link
 			$('#hide8 .jNiceRadio').click(function() {
			$('#yes_layer8').hide('fast');
			return false;
 			});
					// shows the slickbox on clicking the noted link
 			$('#show9 .jNiceRadio').click(function() {
			$('#yes_layer9').show('slow');
			return false;
 			});
			
			// hides the slickbox on clicking the noted link
 			$('#hide9 .jNiceRadio').click(function() {
			$('#yes_layer9').hide('fast');
			return false;
 			});
					// shows the slickbox on clicking the noted link
 			$('#show10 .jNiceRadio').click(function() {
			$('#yes_layer10').show('slow');
			return false;
 			});
			
			// hides the slickbox on clicking the noted link
 			$('#hide10 .jNiceRadio').click(function() {
			$('#yes_layer10').hide('fast');
			return false;
 			});
					// shows the slickbox on clicking the noted link
 			$('#show11 .jNiceRadio').click(function() {
			$('#yes_layer11').show('slow');
			return false;
 			});
			
			// hides the slickbox on clicking the noted link
 			$('#hide11 .jNiceRadio').click(function() {
			$('#yes_layer11').hide('fast');
			return false;
 			});
					// shows the slickbox on clicking the noted link
 			$('#show12 .jNiceRadio').click(function() {
			$('#yes_layer12').show('slow');
			return false;
 			});
			
			// hides the slickbox on clicking the noted link
 			$('#hide12 .jNiceRadio').click(function() {
			$('#yes_layer12').hide('fast');
			return false;
 			});
					// shows the slickbox on clicking the noted link
 			$('#show13 .jNiceRadio').click(function() {
			$('#yes_layer13').show('slow');
			return false;
 			});
			
			// hides the slickbox on clicking the noted link
 			$('#hide13 .jNiceRadio').click(function() {
			$('#yes_layer13').hide('fast');
			return false;
 			});
					// shows the slickbox on clicking the noted link
 			$('#show14 .jNiceRadio').click(function() {
			$('#yes_layer14').show('slow');
			return false;
 			});
			
			// hides the slickbox on clicking the noted link
 			$('#hide14 .jNiceRadio').click(function() {
			$('#yes_layer14').hide('fast');
			return false;
 			});
					// shows the slickbox on clicking the noted link
 			$('#show15 .jNiceRadio').click(function() {
			$('#yes_layer15').show('slow');
			return false;
 			});
			
			// hides the slickbox on clicking the noted link
 			$('#hide15 .jNiceRadio').click(function() {
			$('#yes_layer15').hide('fast');
			return false;
 			});
		
		
/* - CODE FOR VALIDATION - IF NEEDED
    	if ($("input[@name='yn1']:checked").val() == '1'){
        // Code for handling value '1'
		alert("Yes");
			}else if ($("input[@name='yn1']:checked").val() == '0'){
        // Code for handling value '0'
		alert("No")
			}else{
        // Code for handling 'nothing'
		alert("nothing")
			};
*/
		
		
		
		
		
		
		});