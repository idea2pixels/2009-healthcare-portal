				<h2 class="logo"><a href="/"><?=$template["companyName"]?></a></h2>
