			<div class="module-cap-bottom"></div>  <!-- for skinning purposes only, rounded corder cap -->
		</div>
		<div class="footer">
			<div class="module-cap-top"></div> <!-- for skinning purposes only, rounded corder cap -->
				<div class="footer-bg"><!-- for skinning purposes only, footer background -->
					<div class="alere">
						<p class="powered-by">Powered by</p>
						<h3>Alere</h3>
						<p>&copy; 2009 Alere. All rights reserved. Alere is a trademark of the Inverness Medical group of companies.</p>
					</div>
				</div>
			<div class="module-cap-bottom"></div> <!-- for skinning purposes only, rounded corder cap -->
		</div>
	</div>
	<!-- Leave Scripts at the bottom to make sure they don't block the initial paint -->
	<script src="cmn/js/jquery.js"></script>
	<script src="cmn/js/jquery-delegate.js"></script>
	<script src="cmn/js/jquery_example/jquery.example.min.js"></script>
	<script src="cmn/js/global.js"></script>
	<?php if(isset($_GET['debug'])) { include("cmn/inc/debug.inc.php"); } ?>
</body>
</html>