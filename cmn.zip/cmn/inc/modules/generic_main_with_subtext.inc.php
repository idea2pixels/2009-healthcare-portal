				<div class="module">
					<h4><strong><?=$template["credits"]?></strong> credits</h4>
					<img class="picture" src="cmn/img/modules/tmp/module-a-picture2.png" width="118" height="118" alt="Module A Picture">
					<h2>Chug-a-Lug Challenge <span>(Ends 4/24)</span></h2>
					<p>Keep yourself hydrated and keep yourself healthy! <a href="#">Join this challenge</a> and commit to drinking more water.</p>
					<p class="sub-copy">Join 363 people taking this challenge now!</p>
					<ul class="utility-nav">
						<li class="first"><a href="#">Show more like this</a></li>
						<li><a href="#">Don’t show again</a></li>
						<li class="tell-more"><a href="#">Tell me more</a></li>
					</ul>
					<a href="#" class="action-button"><strong><em>Join Now</em></strong></a>
				</div>