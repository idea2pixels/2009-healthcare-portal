				<div class="module b option-select-with-image five-options">
					<img class="icon" src="cmn/img/modules/tmp/module-b-icon_happyface.png" width="36" height="36" alt="Module Icon">
					<h2>How are you feeling right now?</h2>
					<form id="how-are-you-feeling">
						<label class="first" for="how-are-you-feeling-great">
							<input type="radio" id="how-are-you-feeling-great" name="how-are-you-feeling-feeling"> 
							Great!
						</label>

						<label class="second" for="how-are-you-feeling-good">
							<input type="radio" id="how-are-you-feeling-good" name="how-are-you-feeling-feeling"> 
							Good
						</label>

						<label class="third" for="how-are-you-feeling-ok">
							<input type="radio" id="how-are-you-feeling-ok" name="how-are-you-feeling-feeling">
							OK
						</label>
		
						<label class="fourth" for="how-are-you-feeling-eh">
							<input type="radio" id="how-are-you-feeling-eh" name="how-are-you-feeling-feeling">
							Eh
						</label>
		
						<label class="fifth" for="how-are-you-feeling-awful">
							<input type="radio" id="how-are-you-feeling-awful" name="how-are-you-feeling-feeling">
							Awful
						</label>

						<label class="text-entry last" for="how-are-you-feeling-why">
							Why?
							<textarea id="how-are-you-feeling-why" name="how-are-you-feeling-why" rows="8" cols="40"></textarea>
						</label>
					</form>
					<ul class="utility-nav">
						<li class="first"><a href="#">Show more like this</a></li>
						<li class="last"><a href="#">Don’t show again</a></li>
					</ul>
					<a href="#" class="action-button alt"><strong><em>Save Stress Level</em></strong></a>
				</div>