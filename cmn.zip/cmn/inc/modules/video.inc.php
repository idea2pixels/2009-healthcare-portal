				<div class="module b has-video">
					<img class="icon" src="cmn/img/modules/tmp/module-b-icon-read.png" width="35" height="26" alt="Module Icon">
					<h2>Watch Videos About Diabetes</h2>
					<p>Find out how to give yourself insulin injections, and what equipment is required. Find out how to equipment is required <a href="#">Watch the video now</a>.	</p>
					<p class="sub-copy"><a href="#" class="favorited">363 People liked this</a></p>
					<img class="powered-by" src="cmn/img/modules/tmp/logo-healthwise.png" width="153" height="35" alt="Logo Healthwise">
					<div class="video"><img src="cmn/img/modules/tmp/video.png" width="190" height="142" alt="Video"></div>
					<ul class="utility-nav">
						<li class="first"><a href="#">Show more like this</a></li>
						<li class="last"><a href="#">Don’t show again</a></li>
					</ul>
					 <a href="#" class="more">More Videos &raquo;</a>
				</div>