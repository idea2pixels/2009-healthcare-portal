				<div class="module b">
					<img class="icon" src="cmn/img/modules/tmp/module-b-icon-read.png" width="35" height="26" alt="Module Icon">
					<h2>Read About Diabetes</h2>
					<ul>
						<li><a href="#">What is prediabetes?</a> <a href="#" class="favorited" title="Favorites">510</a></li>
						<li><a href="#">Relationships between Diabetes and Cancer</a> <a class="favorited" href="#" title="Favorites">231</a></li>
						<li><a href="#">Sick-Day Guidlines for People With Diabetes</a> <a class="favorited" href="#" title="Favorites">13</a></li>					
					</ul>
					<ul class="utility-nav">
						<li class="first"><a href="#">Show more like this</a></li>
						<li><a href="#">Don’t show again</a></li>
						<li class="tell-more"><a href="#">Tell me more</a></li>
					</ul>
					<a href="#" class="more">Read More <span>&raquo;</span></a>
				</div>