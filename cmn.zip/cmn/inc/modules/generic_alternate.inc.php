				<div class="module b">
					<img class="icon" src="cmn/img/modules/tmp/module-b-icon1.png" width="36" height="36" alt="Module Icon">
					<h2>Finish Your At-Home Screening</h2>
					<p>You should have received your test kit in the mail. Please return it so we can show your results. If there’s a problem, <a href="#">we can help</a>.</p>
					<ul class="utility-nav">
						<li class="first"><a href="#">Show more like this</a></li>
						<li><a href="#">Don’t show again</a></li>
						<li class="tell-more"><a href="#">Tell me more</a></li>
					</ul>
					<p class="partner-link-warning">
						This link will take you to a partner site to enroll. <a href="#" class="action-button alt"><strong><em>Enroll Now</em></strong></a>
					</p>
				</div>