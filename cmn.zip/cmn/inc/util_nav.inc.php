		<strong class="welcome">Hello, <?=$template["userName"]?>.</strong>
		<ul>
			<li class="home"><a href="/">Home</a></li>
			<li class="messages"><a href="#">Messages: <strong>2</strong></a></li>
			<li><a href="#">Account</a></li>
			<li><a href="#">Feedback</a></li>
			<li><a href="#">Logout</a></li>
		</ul>
		<div class="help"><a href="#">Help</a></div>